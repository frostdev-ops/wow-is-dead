this supports 2 mods and has only been tested on fabric 1.20.1


Currently supported mods:
better nether

regions unexplored
